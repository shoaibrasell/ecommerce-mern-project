#ecommerce mern Stack project

##Basic setup

1. Course plan
2. Environment setup
3. Create express server setup -->express
4. HTTP request & response
5. nodemon and morgan package --> nodemon, morgan
6. API testing with Postman
7. Middleware & types of Middleware {1.application-middleware, 2.router-level-middleware ,3.   error-handling-middleware, 4.built-in-middleware, 5.third-party-middleware }
8. Express Error Handling Middleware --> body-parser
9. How to handle HTTP errors -->  http-errors
10. How to secure API -> xss-clean , express-rate-limit
11. Environment variable & gitignore
12. Model View Controller Architecture
13. connect to MongoDB database
14. Schema & Model for User
15. create seed route for testing
16. GET /api/users -> isAdmin -> getAllUsers ->
searchByNAME + pagination functionality
17. responseHandle controller for error or success 
18. GET /api/users/:id -> get a single user by id 
19. How to create services in the backend
20. DELETE /api/users/:id->delete a single user by id
21. Refactoring & reusability , dynamic
22. deleteImage helper
23. POST /api/users/process-register -> process the registration
24. Create JWT
25. setup smtp server & prepare email
26. send email with nodemailer
27. POST /api/users/verify -> verify + register into database
28. add express validator middleware
29. add multer middleware for file upload
30. PUT /api/users/:id -> update a single user by id


email api token
<!-- http://localhost:3000/api/users/activate/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiU2hvYWliIFVsbGFoIFJhc2VsIiwiZW1haWwiOiJzaG9haWJ1bGxhaHJhc2VsQGdtYWlsLmNvbSIsInBhc3N3b3JkIjoiMTIzNDU2IiwicGhvbmUiOiIwMTc0NzE1NTc4NDg5IiwiYWRkcmVzcyI6ImRoYWthLGJhbmdsYWRlc2giLCJpYXQiOjE2ODY1OTM5NTUsImV4cCI6MTY4NjU5NDU1NX0.-dfcOU_bce4Ysn7b9Fp0NmV3rl_0IgfbEtj6VoC__HE -->