// const {body} = require("express-validator");
// //registration validation
// const validateUserRegistration =[
//     //name
//     body("name")
//     .trim()
//     .notEmpty()
//     .withMessage('Name is required')
//     .isLength({min:3 ,max:31})
//     .withMessage('Name should be at least 3-31 characters long pleas'),
//     //email
//     body("email")
//     .trim()
//     .notEmpty()
//     .withMessage('Email is required')
//     .isEmail()
//     .withMessage('Invalid email address'),
//     //password
//     body("password")
//     .trim()
//     .notEmpty()
//     .withMessage('Password is required')
//     .isLength({min: 7 })
//     .withMessage('Password should be at least 6 characters long'),
//     //Address
//     body("Address")
//     .trim()
//     .notEmpty()
//     .withMessage('Address is required')
//     .isLength({min: 3 })
//     .withMessage('Address should be at least 3 characters long'),
//     //phone
//     body("phone")
//     .trim()
//     .notEmpty()
//     .withMessage('Phone number is required')
//     //Image
//     body("Image")
//     .optional()
//     .isString()
//     .withMessage('Address is required')
//     .isLength({min: 3 })
//     .withMessage('Address should be at least 3 characters long'),
// ];

// //sign in validation


// module.exports = { validateUserRegistration };

const { body } = require("express-validator");

//registration validation
const validateUserRegistration = [
    //name
    body("name")
    .trim()
    .notEmpty()
    .withMessage('Name is required')
    .isLength({ min: 3, max: 31 })
    .withMessage('Name should be at least 3-31 characters long pleas'),
    
    //email
    body("email")
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Invalid email address'),
    
    //password
    body("password")
    .trim()
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 7 })
    .withMessage('Password should be at least 6 characters long'),
    
    //Address
    body("Address")
    .trim()
    .notEmpty()
    .withMessage('Address is required')
    .isLength({ min: 3 })
    .withMessage('Address should be at least 3 characters long'),
    
    //phone
    body("phone")
    .trim()
    .notEmpty()
    .withMessage('Phone number is required'), // <-- Add the comma here
    
    //Image
    body("Image")
    .optional()
    .isString()
    .withMessage('Address is required')
    .isLength({ min: 3 })
    .withMessage('Address should be at least 3 characters long'),
];

//sign in validation

module.exports = { validateUserRegistration };
