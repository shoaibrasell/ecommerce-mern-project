const UPLOAD_USER_IMG_DIRECTORY = "public/images/users";
const MAX_FILE_SIZE = 100097152;
const ALLOWED_FILE_TYPES = ["jpg", "png", "jpeg"];

module.exports = {
    UPLOAD_USER_IMG_DIRECTORY,
    MAX_FILE_SIZE,
    ALLOWED_FILE_TYPES
}