const data = {
    users :[
        {
            name : 'ashikur Rahman ashik',
            email : '18203003@iubat.edu',
            password : '123456',
            phone : '017745138',
            address : 'Dhaka ,bangladesh',
        },
        {
            name : 'Perves Samat Pappu',
            email : '182030@iubat.edu',
            password : '123456',
            phone : '017745138',
            address : 'Dhaka ,bangladesh',
        },
    ],
};
module.exports = data;